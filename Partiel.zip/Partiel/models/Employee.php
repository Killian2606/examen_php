<?php
class Employee {
    // Connexion
    private $connexion;
    private $table = "Employee";

    // object properties
    public $id;
    public $name;
    public $email;
    public $age;
    public $designation;
    public $created;

    /**
     * Constructeur avec $db pour la connexion à la base de données
     *
     * @param $db
     */
    public function __construct($db){
        $this->connexion = $db;
    }

    /**
     * 
     *
     * @return void
     */
    public function lire(){
        $sql = "SELECT * FROM Employee";

        $query = $this->connexion->prepare($sql);

        $query->execute();

        return $query;
    }

    /**
     * 
     *
     * @return void
     */
    public function updateEmployee($id) {
        $data = json_decode(file_get_contents("php://input"));
    
        if(
            !empty($data->name) &&
            !empty($data->email) &&
            !empty($data->age) &&
            !empty($data->designation)
        ){
            $sql = "UPDATE " . $this->table . " SET name=:name, email=:email, age=:age, designation=:designation WHERE id=:id";
    
            $query = $this->connexion->prepare($sql);
    
            $this->name=htmlspecialchars(strip_tags($data->name));
            $this->email=htmlspecialchars(strip_tags($data->email));
            $this->age=htmlspecialchars(strip_tags($data->age));
            $this->designation=htmlspecialchars(strip_tags($data->designation));
    
            $query->bindParam(":name", $this->name);
            $query->bindParam(":email", $this->email);
            $query->bindParam(":age", $this->age);
            $query->bindParam(":designation", $this->designation);
            $query->bindParam(":id", $id);
    
            if($query->execute()){
                return true;
            }
        }
        return false;
    }

    /**
     * 
     *
     * @return void
     */
    public function deleteEmployee() {
        $data = json_decode(file_get_contents("php://input"));
    
        if(!empty($data->id)){
            $sql = "DELETE FROM " . $this->table . " WHERE id=:id";
    
            $query = $this->connexion->prepare($sql);
    
            $this->id=htmlspecialchars(strip_tags($data->id));
    
            $query->bindParam(":id", $this->id);

            if($query->execute()){
                return true;
            }
        }
        return false;
    }

}