<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if($_SERVER['REQUEST_METHOD'] == 'GET'){
	include_once '../config/Database.php';
	include_once '../models/Employee.php';

	$database = new Database();
	$db = $database->getConnection();

	$employee = new Employee($db);

	$stmt = $employee->lire();

	if($stmt->rowCount() > 0){
	    $tableauEmployee = [];
	    $tableauEmployee['employee'] = [];

	    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
	        extract($row);

	        $prod = [
	            "id" => $id,
	            "name" => $name,
	            "email" => $email,
	            "age" => $age,
	            "designation" => $designation,
	            "created" => $created
	        ];

	        $tableauEmployee['employee'][] = $prod;
	    }
	    http_response_code(200);

	    echo json_encode($tableauEmployee);
	}

} else {
    http_response_code(405);
    echo json_encode(["message" => "La méthode n'est pas autorisée"]);
}

?>